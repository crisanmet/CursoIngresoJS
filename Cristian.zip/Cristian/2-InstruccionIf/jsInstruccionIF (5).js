function Mostrar()
{
//tomo la edad  

    var edad;

    edad = document.getElementById("edad").value;
    edad = parseInt(edad);

    if ()


}//FIN DE LA FUNCIÓN